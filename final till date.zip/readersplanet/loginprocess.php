<?php session_start();

$link = mysqli_connect("localhost","root","","book_store");
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

						
							

	
	if(!empty($_POST))
	{
		$msg="";
		
		if(empty($_POST['Uname']))
		{
            echo '<br><b>Error:-</b><br>Empty username';
			
		}
		
		if(empty($_POST['Pass']))
		{
            echo '<br><b>Error:-</b><br>Empty Password';
			
		}
		
		
		
		else
		{
			
			
	
			
			$unm=$_POST['Uname'];
			
			
			$q="select * from register where Email='$unm'";
			
			$res=mysqli_query($link,$q) or die("wrong query");
			
			$row=mysqli_fetch_assoc($res);
			
			if(!empty($row))
			{
				if($_POST['Pass']==$row['Password'])
				{
					$_SESSION=array();
					$_SESSION['type']=$row['Status'];
					$_SESSION['name']=$row['Name'];
					$_SESSION['status']=true;
					
					if($_SESSION['type']!="admin")
					{
						header("location:login.php");
					}
					else
					{
						header("location:admin/index.php");
					}
				}
				
				else
				{
					echo 'Incorrect Password....';
				}
			}
			else
			{
				echo 'Invalid User';
			}
		}
	
	}
	else
	{
		header("location:loginprocess.php");
	}
			
?>