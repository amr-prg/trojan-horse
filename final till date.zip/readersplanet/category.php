<?php session_start();
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost","root","","book_store");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
	//catch the value of id using GET method in ID variable 
 
// Attempt select query execution
$sql = "SELECT * FROM book ";
$res=mysqli_query($link,$sql) or die("Can't Execute Query..");
 //fetch book querry filter by BookID
	

   


?>
<!DOCTYPE html>
<html lang="en">
<head>
<style>
  
   

  </style>
    <meta charset="UTF-8">
    <!-- Important to make website responsive -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>

    <!-- Link our CSS file -->
    <link rel="stylesheet" href="css/style1.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
   <header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">ReadersPlanet</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item ">
              <a class="nav-link" href="index_su.php">Home <span class="sr-only">(current)</span></a>     <!--Home page anchor link-->
            </li>
           
      
            <li class="nav-item">
      <?php 
if(isset($_SESSION['type'])=="user")
{

echo '<a class="nav-link" href="logout.php">Logout</a>';

}else{
  echo '<a class="nav-link" href="login.php">Login</a>';
}
?>
        
      </li>

            <li class="nav-item">
              <a class="nav-link" href="register.php">Register</a>   <!--New Registration page link-->
            </li>
      
            <li class="nav-item active">
              <a class="nav-link" href="category.php">Categories</a>     <!--Books Categories page link-->
            </li>
            
            <li class="nav-item">
              <a class="nav-link" href="contact.php">Contact us</a>      <!--Contact us page link-->
            </li>
      
            <li class="nav-item">
              <a class="nav-link" href="cart.php">Cart</a>               <!--Shopping cart page link-->
            </li>
      
          </ul>
          <form class="form-inline my-2 my-lg-0" action="Search.php" method="GET">
            <input class="form-control mr-sm-2" type="search" placeholder="Type Book Name" aria-label="Search" name="bookname">
            <button class="btn btn-outline-success my-2 my-sm-0" name="submit" type="submit">Find books now</button>
            
          </form>
        </div>
      </nav>
</header>
<body >
    <!-- CAtegories Section Starts Here -->
    <section class="categories">
        <div class="container">
            <h2 class="text-center">Book Store Categories</h2>

            <a href="category-foods.html">
            <div class="box-3 float-container">
                <img src="images/1 book.jpg" alt="Pizza" class="img-responsive img-curve">

                <h3 class="float-text text-white">The book of Love</h3>
                <p>Romance</p>
            </div>
            </a>

            <a href="#">
            <div class="box-3 float-container">
                <img src="images/2 jaws.jpg" alt="Burger" class="img-responsive img-curve">

                <h3 class="float-text text-white">Jaws</h3>
                <P>Thriller</P>
            </div>
            </a>

            <a href="#">
            <div class="box-3 float-container">
                <img src="images/3 kite.jpg" alt="Momo" class="img-responsive img-curve">

                <h3 class="float-text text-white">The kite runner</h3>
                <p>Biography</p>
            </div>
            </a>

            <div class="clearfix"></div>
        </div>
    </section>
    <!-- Categories Section Ends Here -->
	<section class="book-menu">
        <div class="book-menu-item">
            <h2 class="text-center">Book Store</h2>
            <div class="book-menu-box">
            <?php
            
            while($row=mysqli_fetch_assoc($res)){
                $category= $row['CategoryID'];
                //get Category name
    
    $cat = "SELECT * FROM category WHERE Id = '$category'";
    
    $catQuerry = mysqli_query($link,$cat);
    //execute the category name.
    $catrow=mysqli_fetch_assoc($catQuerry);
                echo '
                
                <div style={width: "100%";  padding: 20px; margin:20px;}>
                <img src="data:image/png;base64,'.base64_encode($row['Image']).' " width="50%" height="50%"/>
                </div>

                <div style={width: "50%"; float: "right";}>
                    <h4>'.$row['BookTitle'].'</h4>
                    <p class="book-price">$'.$row['Price'].'</p>
                    <p class="book-detail">
                        Category:'.$catrow['Category_name'].'
                    </p>
                    <br>

                    <a href="details.php?id='.$row['BookID'].'" class="btn btn-primary">Order Now</a>
                </div>
           
                ';
                
            }
            ?>
            
            </div>

            

           

            

            

            


            <div class="clearfix"></div>

            

        </div>

       
    </section>
	
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  
</body>
</html>