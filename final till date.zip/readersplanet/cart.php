<?php session_start();
require('Database/config.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <!-- Important to make website responsive -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>

    <!-- Link our CSS file -->
    <link rel="stylesheet" href="css/style1.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
   <header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">ReadersPlanet</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item ">
              <a class="nav-link" href="index_su.php">Home <span class="sr-only">(current)</span></a>     <!--Home page anchor link-->
            </li>
            
            <li class="nav-item">
      <?php 
if(isset($_SESSION['type'])=="user")
{

echo '<a class="nav-link" href="logout.php">Logout</a>';

}else{
  echo '<a class="nav-link" href="login.php">Login</a>';
}
?>
        
      </li>
      
            <li class="nav-item">
              <a class="nav-link" href="register.php">Register</a>   <!--New Registration page link-->
            </li>
      
            <li class="nav-item">
              <a class="nav-link" href="category.php">Categories</a>     <!--Books Categories page link-->
            </li>
            
            <li class="nav-item">
              <a class="nav-link" href="contact.php">Contact us</a>      <!--Contact us page link-->
            </li>
      
            <li class="nav-item active">
              <a class="nav-link" href="cart.php">Cart</a>               <!--Shopping cart page link-->
            </li>
            
      
          </ul>
          <form class="form-inline my-2 my-lg-0" action="Search.php" method="GET">
            <input class="form-control mr-sm-2" type="search" placeholder="Type Book Name" aria-label="Search" name="bookname">
            <button class="btn btn-outline-success my-2 my-sm-0" name="submit" type="submit">Find books now</button>
            
          </form>
        </div>
      </nav>
</header>
<body>
<div id="content">
						<div class="post">
							<h1 class="title">Viewcart</h1>
							<div class="entry">
						
							<pre><?php
                            if(isset($_SESSION['status'])){
                                echo 'Logged in As',' ', $_SESSION['name'];
                            }
                            else{
                                header("location:index_su.php");
                            }
							//	print_r($_SESSION);
							?></pre>
						
							<form action="cart.php" method="POST">
							<table width="100%" border="0">
								<tr >
									<Td> <b>No
									<td> <b>Category
									<td> <b>Product
									<td> <b>Qty
									<td> <b>Rate
									<td> <b>Price
									<td> <b>Delete
								</tr>
								<tr><td colspan="7"><hr style="border:1px Solid #a1a1a1;"></tr>
							
								<?php
									$tot = 0;
									$i = 1;
									if(isset($_SESSION['cart']))
									{

									foreach($_SESSION['cart'] as $id=>$x)
									{	
										echo '
											<tr>
											<Td> '.$i.'
											<td> '.$x['cat'].'
											<td> '.$x['nm'].'
											<td> <input type="text" size="2" value="'.$x['qty'].'" name="'.$id.'">
											<td> '.$x['rate'].'
											<td> '.($x['qty']*$x['rate']).'
											<td> <a href="cartDetails.php?id='.$id.'">Delete</a>
										</tr>
										';
										
										$tot = $tot + ($x['qty']*$x['rate']);
										$i++;
									}
									}
								
								?>
							<tr><td colspan="7"><hr style="border:1px Solid #a1a1a1;"></tr>
								
							<tr>
							<td colspan="6" align="right">
							<h4>Total:</h4>
							
							</td>
							<td> <h4><?php echo $tot; ?> </h4></td>
							</tr>
							<tr><td colspan="7"><hr style="border:1px Solid #a1a1a1;"></tr>
							
							<Br>
								</table>						

								<br><br>
							<center>
							<input type="submit" value=" Re-Calculate " > 
							<a href="">CONFIRM & PROCEED<a/>
							</center>
							</form>
							</div>
							
						</div>
						
					</div>

                    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
