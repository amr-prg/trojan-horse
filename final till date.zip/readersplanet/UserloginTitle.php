<?php
						//connect to database
						$link = mysqli_connect("localhost","root","","book_store");
                        if($link === false){
                            die("ERROR: Could not connect. " . mysqli_connect_error());
                        }
							if(isset($_SESSION['status']))
							
							{
								echo '<h2>Hello :  '.$_SESSION['name'].'</h2>';
							}
?>