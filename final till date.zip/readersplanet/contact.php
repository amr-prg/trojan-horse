<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>Contact US </title>
  <link rel="stylesheet" type="text/css" href="css/style2.css">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<header>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">ReadersPlanet</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
  
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item ">
          <a class="nav-link" href="index_su.php">Home <span class="sr-only">(current)</span></a>     <!--Home page anchor link-->
        </li>
        
       
  
        <li class="nav-item">
      <?php session_start();
      //checks If the user is logged in or not
if(isset($_SESSION['type'])=="user")
{
//If the user logged in, Logout button will display
echo '<a class="nav-link" href="logout.php">Logout</a>';

}else{
  //if the user is not logged in, login button will display
  echo '<a class="nav-link" href="login.php">Login</a>';
}
?>
       </li> 

        <li class="nav-item">
          <a class="nav-link" href="register.php">Register</a>   <!--New Registration page link-->
        </li>
  
        <li class="nav-item">
          <a class="nav-link" href="category.php">Categories</a>     <!--Books Categories page link-->
        </li>
        
        <li class="nav-item active">
          <a class="nav-link" href="contact.php">Contact us</a>      <!--Contact us page link-->
        </li>
  
        <li class="nav-item">
          <a class="nav-link" href="cart.php">Cart</a>               <!--Shopping cart page link-->
        </li>
  
      </ul>
      <form class="form-inline my-2 my-lg-0" action="Search.php" method="GET">
        <input class="form-control mr-sm-2" type="search" placeholder="Type Book Name" aria-label="Search" name="bookname">
        <button class="btn btn-outline-success my-2 my-sm-0" name="submit" type="submit">Find books now</button>
        
      </form>
    </div>
  </nav>
		</header>
  <div class="Container">
    <h1> Connect With Us</h1>
    <h2> We are always ready to help you!</h2>
  </div>
<div class="contact-box">
 <div class="contact-left">
    <h3>Send your request</h3>
<form>
<div class="input-row">
 <div class="input-group">
  <label>Name</label>
  <input type="text" placeholder="Saurav Niraula">
 </div>
<div class="input-group">
  <label>Phone</label>
  <input type="text" placeholder="+61 467 459 235">
 </div>
<div class="input-row">
 <div class="input-group">
  <label>Email</label>
  <input type="email" placeholder="Sauravniroula123@gmail.com">
 </div>
<div class="input-group">
  <label>Subject</label>
  <input type="text" placeholder="Enquiry">
 </div>
<label>Message</label>
<textarea rows="5" placeholder="Your Message">
</textarea>
<button type="submit">SEND</button>
</form>
 <div class="contact-right">
    <h3>Reach Us</h3>
<table>
  <tr>
   <td>Email</td>
   <td>readersplanet@gmail.com</td>
  </tr>
  <tr>
   <td>Phone</td>
   <td>+61 433 708 580</td>
  </tr>
<tr>
   <td>Address</td>
   <td>35 Roberts St, Strathfield
Sydney, Australia</td>

  </tr

</table>
 </div>

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    </body>
</html>