<!DOCTYPE html>
<html>
<head>
  
  <title>www.readersplanet.com</title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" type="text/css" href="css/style_su.css">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

</head>

<body>

<!---------------------------- These below will create top navigation bar------------------------------------------>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">ReadersPlanet</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index_su.php">Home <span class="sr-only">(current)</span></a>     <!--Home page anchor link-->
      </li>
      
      

      <li class="nav-item">
      <?php session_start();
      //checks If the user is logged in or not
if(isset($_SESSION['type'])=="user")
{
//If the user logged in, Logout button will display
echo '<a class="nav-link" href="logout.php">Logout</a>';

}else{
  //if the user is not logged in, login button will display
  echo '<a class="nav-link" href="login.php">Login</a>';
}
?>
       </li> 

      <li class="nav-item">
        <a class="nav-link" href="register.php">Register</a>   <!--New Registration page link-->
      </li>

      <li class="nav-item">
        <a class="nav-link" href="category.php">Categories</a>     <!--Books Categories page link-->
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="contact.php">Contact us</a>      <!--Contact us page link-->
      </li>

      <li class="nav-item">
        <a class="nav-link" href="cart.php">Cart</a>               <!--Shopping cart page link-->
      </li>

    </ul>
    <form class="form-inline my-2 my-lg-0" action="Search.php" method="GET">
      <input class="form-control mr-sm-2" type="search" placeholder="Type Book Name" aria-label="Search" name="bookname">
      <button class="btn btn-outline-success my-2 my-sm-0" name="submit" type="submit">Find books now</button>
      
    </form>
  </div>
</nav>

<!----------------- This below block of code will run sliding images in home page ---------------------->

  <div id="demo" class="carousel slide" data-ride="carousel">
    <ul class="carousel-indicators">
      <li data-target="#demo" data-slide-to="0" class="active"></li>
      <li data-target="#demo" data-slide-to="1"></li>
      <li data-target="#demo" data-slide-to="2"></li>
    </ul>


    <div class="carousel-inner">

      <div class="carousel-item active">
        <img src="images/main_bg.jpg" alt="book_bg" width="1100" height="500">
        <div class="carousel-caption">
          <h1 style="font-size: 30pt;">Find your favorite books here</h1>
        </div>
      </div>

      <div class="carousel-item">
          <img src="images/main_bg0.jpg" alt="book_bg" width="1100" height="500">
          <div class="carousel-caption">
            <h1 style="font-size: 30pt;">Readers Planet, finders heaven</h1>
          </div>
      </div>
      
      <div class="carousel-item">
          <img src="images/main_bg1.jpg" alt="book_bg" width="1100" height="500">
          <div class="carousel-caption">
            <h1 style="font-size: 30pt;">New books released every week</h1>
          </div>
      </div>

    </div>


  <div>
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>

<!-- These codes is for creating "Recommended books" section-->

  <section class="my-5">
    <div class="py-5">
    </div>

    <h2 style="text-align: center; margin-top: -3cm; margin-bottom: 1cm;">Recommended Books</h2>

    <div class="container fluid">
      <div class="row">
        <div class="col-lg-3 col-md-3 col-12">                                          <!--This line will create a 4 column grid-->
          <div class="card">
            <img class="card-img-top" src="images/Book-Image1.jpeg" alt="Card image">   <!--Insert images in the grid-->
            <div class="card-img-overlay">
              <h4 style="margin-top: 10cm;" class="card-title">Yes Please</h4>
              <p class="card-text">#1 New York Times Bestseller.</p>
              <a href="#" class="btn btn-primary">Order now</a>                       <!--Order now button-->                
            </div>
          </div>
        </div>

        <div class="col-lg-3 col-md-3 col-12">
          <div class="card">
            <img class="card-img-top" src="images/Book-Image5.jpeg" alt="Card image">
            <div class="card-img-overlay">
              <h4 style="margin-top: 10cm;" class="card-title">Dracula</h4>
              <p class="card-text">Dead & Alive.</p>
              <a href="#" class="btn btn-primary">Order now</a>
            </div>
          </div>
        </div>

        <div class="col-lg-3 col-md-3 col-12">
          <div class="card">
            <img class="card-img-top" src="images/Book-Image3.jpeg" alt="Card image">
            <div class="card-img-overlay">
              <h4 style="margin-top: 10cm;" class="card-title">Divided Soul</h4>
              <p class="card-text">The Life of Marvin Gaye.</p>
              <a href="#" class="btn btn-primary">Order now</a>
            </div>
          </div>
        </div>

        <div class="col-lg-3 col-md-3 col-12">
          <div class="card">
            <img class="card-img-top" src="images/Book-Image4.jpeg" alt="Card image">
            <div class="card-img-overlay">
              <h4 style="margin-top: 10cm;" class="card-title">Rites of Spring</h4>
              <p class="card-text">The origin, the impact and the aftermath of the Great War.</p>
              <a href="#" class="btn btn-primary">Order now</a>
            </div>
          </div>
        </div>

      </div>
    </div>
      
  </section>

  <!--This lines will insert CDN (Content Delivery Network) template, that
  makes scripts work without having Bootstrap install in the machine-->

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>