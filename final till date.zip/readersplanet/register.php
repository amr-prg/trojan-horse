<!DOCTYPE html>
<html>
<head>
  <style>
    .error {color: red;}
.success {color: green;}
.body {background-image: url("images/bookstore.jpeg"); background-size: cover;}
  </style>
<title>Registration Page</title>
	<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7; IE=EmulateIE9">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
  <link rel="stylesheet" type="text/css" href="css/style4.css" media="all" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body class="body">
  <?php
  //connet to database
include "Database/config.php";
//empty string variable
$msg='';
$success='';
//Check if the button submit
if(isset($_POST['submit']))
{	
    	
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $repass = $_POST['repassword'];
    $status =  'user';

    if($password == $repass){
        $insert = mysqli_query($db,"INSERT INTO `Register`(`Name`, `Email` , `Password`, `Status`) VALUES ('$name','$email', '$password','$status')");

        if(!$insert)
        //if querry doesn't execute will get an error
        {
            $msg =  'error';
        }
        else
        //success when password, email and name are filled correctly 
        {
            $success = "Registered successfully.";
        }
        
    }
    else{
      //error when password and confirmpassword donot match
        $msg = 'Password must be same';
    }
    
}
//close database
mysqli_close($db); 
?>
  <header>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">ReadersPlanet</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item ">
        <a class="nav-link" href="index_su.php">Home <span class="sr-only">(current)</span></a>     <!--Home page anchor link-->
      </li>
      
      

      <li class="nav-item">
      <?php session_start();
      //checks If the user is logged in or not
if(isset($_SESSION['type'])=="user")
{
//If the user logged in, Logout button will display
echo '<a class="nav-link" href="logout.php">Logout</a>';

}else{
  //if the user is not logged in, login button will display
  echo '<a class="nav-link" href="login.php">Login</a>';
}
?>
       </li> 
     

      <li class="nav-item active">
        <a class="nav-link" href="register.php">Register</a>   <!--New Registration page link-->
      </li>

      <li class="nav-item">
        <a class="nav-link" href="category.php">Categories</a>     <!--Books Categories page link-->
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="contact.php">Contact us</a>      <!--Contact us page link-->
      </li>

      <li class="nav-item">
        <a class="nav-link" href="cart.php">Cart</a>               <!--Shopping cart page link-->
      </li>

    </ul>
    <form class="form-inline my-2 my-lg-0" action="Search.php" method="GET">
      <input class="form-control mr-sm-2" type="search" placeholder="Type Book Name" aria-label="Search" name="bookname">
      <button class="btn btn-outline-success my-2 my-sm-0" name="submit" type="submit">Find books now</button>
      
    </form>
  </div>
</nav>
</header>
<div class="container">
			<!-- freshdesignweb top bar -->
            <div class="freshdesignweb-top">
                <div class="clr"></div>
                
            </div><!--/ freshdesignweb top bar -->      
            <div  class="form" >
			<form  id="Registerform" method="POST" action="register.php">
				<p><label for="name">Name</label></p>
				<input id="name" name="name" placeholder="First and last name" required="" tabindex="1" type="text">

				<p><label for="email">Email</label></p>
				<input id="email" name="email" placeholder="example@domain.com" required="" type="email">



				<p><label for="password">Create a password</label></p>
				<input type="password" id="password" name="password" required="">
				<p><label for="repassword">Confirm your password</label></p>
				<input type="password" id="repassword" name="repassword" required="">
				<input class="buttom" name="submit" id="submit" tabindex="5" value="Register here....." type="submit">
                <p><span class="error"><?php echo $msg;?></span></p>
                <p><span class="success"><?php echo $success;?></span></p>
			</form>
      <?php
						$link = mysqli_connect("localhost","root","","book_store");
                        if($link === false){
                            die("ERROR: Could not connect. " . mysqli_connect_error());
                        }
							if(isset($_SESSION['status']))
							{
								echo '<h2>Hello :  '.$_SESSION['name'].'</h2>';
							}
?>
		</div>      
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
